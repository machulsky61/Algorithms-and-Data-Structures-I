#include "electores.h"

int validarVotante(int a, int m, int d) {
	return NO_VOTA;
	// Borrar el return dummy y completar
}
